# Fiji

Fiji is an all-in one package manager for Python